export type PaymentInit={orderNumber:string;amount:number;customerName:string;phone:string;email?:string|null};
export type PaymentResult={status:"PENDING"|"PAID";redirectUrl?:string;providerRef?:string};
export interface PaymentProvider { initialize(input:PaymentInit):Promise<PaymentResult>; verifyWebhook(payload:unknown,signature?:string):Promise<{orderNumber:string;paid:boolean;providerRef?:string}>; }
export function getPaymentProvider(name:string):PaymentProvider{
  if(name.toLowerCase()==="cod") return {async initialize(){return {status:"PENDING"}},async verifyWebhook(){throw new Error("COD has no online webhook")}};
  throw new Error(`Payment provider ${name} is not configured. Add credentials server-side before enabling it.`);
}
// Adapter boundary for bKash/Nagad/SSLCommerz. Never put provider secrets in browser code.
