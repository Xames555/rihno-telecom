export type Notification={to:string;subject:string;message:string};
export interface NotificationProvider{send(n:Notification):Promise<void>}
export const disabledNotificationProvider:NotificationProvider={async send(){throw new Error("Notification provider not configured. Connect a verified email/SMS/WhatsApp provider before enabling notifications.")}};
// Keep provider credentials server-side. Add adapters for email, SMS and WhatsApp Cloud/API providers here.
