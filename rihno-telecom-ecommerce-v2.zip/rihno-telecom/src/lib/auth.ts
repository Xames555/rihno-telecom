import { cookies } from "next/headers";
import { SignJWT, jwtVerify } from "jose";
import { prisma } from "./prisma";

const secret = new TextEncoder().encode(process.env.AUTH_SECRET || "dev-only-change-me");

export async function createSession(userId: string) {
  const token = await new SignJWT({ userId }).setProtectedHeader({ alg: "HS256" })
    .setIssuedAt().setExpirationTime("7d").sign(secret);
  const jar = await cookies();
  jar.set("rt_session", token, { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "lax", path: "/", maxAge: 60 * 60 * 24 * 7 });
}

export async function getCurrentUser() {
  const token = (await cookies()).get("rt_session")?.value;
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, secret);
    if (!payload.userId || typeof payload.userId !== "string") return null;
    return prisma.user.findUnique({ where: { id: payload.userId } });
  } catch { return null; }
}

export async function requireAdmin() {
  const user = await getCurrentUser();
  if (!user?.role || !user.active) throw new Error("UNAUTHORIZED");
  return user;
}
