import { cookies } from "next/headers";
import { prisma } from "@/lib/prisma";

export default async function Checkout() {
  const cart=JSON.parse((await cookies()).get("rt_cart")?.value || "[]") as {productId:string,quantity:number}[];
  const products=await prisma.product.findMany({where:{id:{in:cart.map(x=>x.productId)}}});
  const total=cart.reduce((s,i)=>{const p=products.find(x=>x.id===i.productId);return s+(p?Number(p.salePrice??p.price)*i.quantity:0)},0);
  return <main className="container max-w-4xl py-12"><h1 className="text-4xl font-black">Checkout</h1><form action="/api/orders" method="post" className="mt-8 grid gap-4">
    <input name="customerName" required placeholder="Full Name" className="min-h-12 rounded-xl border border-white/10 bg-[#151515] px-4"/>
    <input name="phone" required placeholder="Mobile Number" className="min-h-12 rounded-xl border border-white/10 bg-[#151515] px-4"/>
    <input name="email" type="email" placeholder="Email (optional)" className="min-h-12 rounded-xl border border-white/10 bg-[#151515] px-4"/>
    <textarea name="address" required placeholder="Delivery Address" className="min-h-28 rounded-xl border border-white/10 bg-[#151515] p-4"/>
    <input name="area" placeholder="Area" className="min-h-12 rounded-xl border border-white/10 bg-[#151515] px-4"/>
    <input name="district" required placeholder="District" className="min-h-12 rounded-xl border border-white/10 bg-[#151515] px-4"/>
    <input name="postalCode" placeholder="Postal Code" className="min-h-12 rounded-xl border border-white/10 bg-[#151515] px-4"/>
    <input name="couponCode" placeholder="Coupon code (optional)" className="min-h-12 rounded-xl border border-white/10 bg-[#151515] px-4"/>
    <textarea name="notes" placeholder="Order notes" className="min-h-20 rounded-xl border border-white/10 bg-[#151515] p-4"/>
    <select name="paymentMethod" className="min-h-12 rounded-xl border border-white/10 bg-[#151515] px-4"><option value="COD">Cash on Delivery</option><option value="ONLINE">Online payment (configure gateway)</option></select>
    <div className="surface flex items-center justify-between rounded-2xl p-5"><span>Total</span><strong className="text-2xl">৳{total.toLocaleString()}</strong></div>
    <button className="btn btn-primary min-h-12">Place Order</button>
  </form></main>
}
