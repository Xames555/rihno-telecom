import Link from "next/link";
import { cookies } from "next/headers";
import { prisma } from "@/lib/prisma";

export default async function CartPage() {
  const cart=JSON.parse((await cookies()).get("rt_cart")?.value || "[]") as {productId:string,quantity:number}[];
  const products=await prisma.product.findMany({where:{id:{in:cart.map(x=>x.productId)}}});
  const rows=cart.map(i=>({i,p:products.find(p=>p.id===i.productId)})).filter(x=>x.p);
  const total=rows.reduce((s,x)=>s+Number(x.p!.salePrice??x.p!.price)*x.i.quantity,0);
  return <main className="container py-12"><h1 className="text-4xl font-black">Your Cart</h1>{rows.length===0?<div className="surface mt-8 rounded-2xl p-10 text-center"><p className="text-white/60">Your cart is empty.</p><Link className="btn btn-primary mt-5" href="/products">Start Shopping</Link></div>:<><div className="mt-8 grid gap-4">{rows.map(x=><div key={x.p!.id} className="surface flex items-center justify-between rounded-2xl p-4"><div><div className="font-bold">{x.p!.name}</div><div className="text-sm text-white/50">Qty {x.i.quantity}</div></div><div className="font-black">৳{(Number(x.p!.salePrice??x.p!.price)*x.i.quantity).toLocaleString()}</div></div>)}</div><div className="surface mt-6 flex items-center justify-between rounded-2xl p-5"><span className="font-bold">Subtotal</span><span className="text-2xl font-black">৳{total.toLocaleString()}</span></div><Link className="btn btn-primary mt-5" href="/checkout">Proceed to Checkout</Link></>}</main>
}
