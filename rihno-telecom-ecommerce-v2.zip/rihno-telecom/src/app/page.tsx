import Link from "next/link";
import { prisma } from "@/lib/prisma";

export default async function Home() {
  const [products, categories] = await Promise.all([
    prisma.product.findMany({ where:{active:true}, orderBy:{createdAt:"desc"}, take:8 }),
    prisma.category.findMany({ where:{active:true}, orderBy:{sortOrder:"asc"}, take:10 })
  ]);
  return <main>
    <section className="relative overflow-hidden border-b border-white/10">
      <div className="container grid min-h-[560px] items-center gap-10 py-16 md:grid-cols-2">
        <div>
          <p className="orange mb-3 font-bold uppercase tracking-[.25em]">RIHNO TELECOM</p>
          <h1 className="text-5xl font-black leading-tight md:text-7xl">Technology That Keeps You <span className="orange">Connected.</span></h1>
          <p className="mt-6 max-w-xl text-lg text-white/60">Discover quality technology products, telecom accessories and smart solutions from Rihno Telecom.</p>
          <div className="mt-8 flex flex-wrap gap-3"><Link className="btn btn-primary" href="/products">Shop Now</Link><Link className="btn btn-ghost" href="/categories">Explore Products</Link></div>
        </div>
        <div className="surface glow relative min-h-[340px] overflow-hidden rounded-3xl p-8">
          <div className="absolute -right-20 -top-20 h-64 w-64 rounded-full bg-orange-500/20 blur-3xl"/>
          <div className="relative flex h-full items-center justify-center"><div className="text-center"><div className="text-8xl font-black orange">RT</div><p className="mt-4 text-white/60">Premium technology, made simple.</p></div></div>
        </div>
      </div>
    </section>
    <section className="container py-16"><div className="mb-7 flex items-end justify-between"><div><p className="orange font-bold">SHOP BY CATEGORY</p><h2 className="mt-2 text-3xl font-black">Find what you need</h2></div><Link className="text-sm orange" href="/categories">View all →</Link></div>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-5">{categories.map(c=><Link key={c.id} href={`/categories/${c.slug}`} className="surface rounded-2xl p-5 transition hover:-translate-y-1 hover:border-orange-500/50"><div className="text-lg font-bold">{c.name}</div><div className="mt-2 text-xs text-white/40">Explore products →</div></Link>)}</div>
    </section>
    <section className="container pb-16"><div className="mb-7 flex items-end justify-between"><div><p className="orange font-bold">NEW & FEATURED</p><h2 className="mt-2 text-3xl font-black">Popular picks</h2></div><Link className="text-sm orange" href="/products">Shop all →</Link></div>
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">{products.map(p=><Link key={p.id} href={`/products/${p.slug}`} className="surface overflow-hidden rounded-2xl p-3 transition hover:-translate-y-1"><div className="flex aspect-square items-center justify-center rounded-xl bg-[#0b0b0b] text-4xl font-black orange">RT</div><div className="p-2"><h3 className="line-clamp-2 font-bold">{p.name}</h3><p className="mt-2 font-black">৳{Number(p.salePrice ?? p.price).toLocaleString()}</p>{p.salePrice && <p className="text-xs text-white/40 line-through">৳{Number(p.price).toLocaleString()}</p>}</div></Link>)}</div>
    </section>
  </main>
}
