import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/prisma";
import { createSession } from "@/lib/auth";
export async function POST(req:Request){const f=await req.formData();const phone=String(f.get("phone")||"");const password=String(f.get("password")||"");const u=await prisma.user.findUnique({where:{phone}});if(!u?.passwordHash||!u.role||!await bcrypt.compare(password,u.passwordHash))return NextResponse.redirect(new URL("/admin/login?error=1",req.url));await createSession(u.id);return NextResponse.redirect(new URL("/admin",req.url));}