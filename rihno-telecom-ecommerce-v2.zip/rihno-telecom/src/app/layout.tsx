import type { Metadata } from "next";
import "./globals.css";
import Link from "next/link";
import { ShoppingCart, Search, MessageCircle } from "lucide-react";

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || "https://www.rihnotelecom.com"),
  title: { default: "Rihno Telecom", template: "%s | Rihno Telecom" },
  description: "Technology That Keeps You Connected.",
  openGraph: { type: "website", siteName: "Rihno Telecom", title: "Rihno Telecom", description: "Technology That Keeps You Connected." },
  robots: { index: true, follow: true }
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>
    <header className="sticky top-0 z-50 border-b border-white/10 bg-[#0b0b0b]/95 backdrop-blur">
      <div className="container flex h-16 items-center gap-4">
        <Link href="/" className="text-xl font-black tracking-tight"><span className="orange">Rihno</span> Telecom</Link>
        <nav className="ml-auto hidden gap-5 text-sm text-white/80 md:flex">
          <Link href="/">Home</Link><Link href="/products">Shop</Link><Link href="/categories">Categories</Link>
          <Link href="/offers">Offers</Link><Link href="/blog">Blog</Link><Link href="/about">About Us</Link><Link href="/contact">Contact</Link>
        </nav>
        <div className="ml-auto flex items-center gap-2 md:ml-4">
          <Link aria-label="Search" href="/products" className="btn btn-ghost p-2"><Search size={18}/></Link>
          <a aria-label="WhatsApp" className="btn btn-ghost hidden p-2 sm:inline-flex" href="https://wa.me/8801627982049"><MessageCircle size={18}/></a>
          <Link aria-label="Cart" href="/cart" className="btn btn-primary p-2"><ShoppingCart size={18}/></Link>
        </div>
      </div>
    </header>
    {children}
    <footer className="mt-20 border-t border-white/10 bg-[#0f0f0f]">
      <div className="container grid gap-8 py-12 md:grid-cols-4">
        <div><div className="text-xl font-black"><span className="orange">Rihno</span> Telecom</div><p className="mt-3 text-sm text-white/60">Technology That Keeps You Connected.</p></div>
        <div><h3 className="font-bold">Shop</h3><div className="mt-3 grid gap-2 text-sm text-white/60"><Link href="/products">All Products</Link><Link href="/categories">Categories</Link><Link href="/offers">Offers</Link></div></div>
        <div><h3 className="font-bold">Customer Service</h3><div className="mt-3 grid gap-2 text-sm text-white/60"><Link href="/contact">Contact</Link><Link href="/track-order">Track Order</Link><Link href="/policies/return">Return Policy</Link></div></div>
        <div><h3 className="font-bold">Contact</h3><p className="mt-3 text-sm text-white/60">WhatsApp: +8801627982049</p><p className="text-sm text-white/60">Facebook: Rihno Telecom</p><p className="text-sm text-white/60">Instagram: Rihno Telecom</p></div>
      </div>
      <div className="border-t border-white/10 py-5 text-center text-xs text-white/40">© {new Date().getFullYear()} Rihno Telecom. All rights reserved.</div>
    </footer>
  </body></html>
}
