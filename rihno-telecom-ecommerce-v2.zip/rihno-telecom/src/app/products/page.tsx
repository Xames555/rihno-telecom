import Link from "next/link";
import { prisma } from "@/lib/prisma";

export default async function Products({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const { q } = await searchParams;
  const products = await prisma.product.findMany({
    where: { active:true, ...(q ? { OR:[{name:{contains:q,mode:"insensitive"}},{sku:{contains:q,mode:"insensitive"}}] } : {}) },
    orderBy:{createdAt:"desc"}
  });
  return <main className="container py-12"><div className="mb-8"><p className="orange font-bold">SHOP</p><h1 className="text-4xl font-black">All Products</h1></div>
    <form className="mb-8 flex gap-2"><input name="q" defaultValue={q} placeholder="Search products..." className="min-h-12 flex-1 rounded-xl border border-white/10 bg-[#151515] px-4 outline-none focus:border-orange-500"/><button className="btn btn-primary">Search</button></form>
    <div className="grid grid-cols-2 gap-4 md:grid-cols-4">{products.map(p=><Link key={p.id} href={`/products/${p.slug}`} className="surface rounded-2xl p-3"><div className="flex aspect-square items-center justify-center rounded-xl bg-[#0b0b0b] text-4xl font-black orange">RT</div><h2 className="mt-3 font-bold">{p.name}</h2><p className="mt-2 font-black">৳{Number(p.salePrice ?? p.price).toLocaleString()}</p>{p.stock<=p.lowStockAt && p.stock>0 && <p className="mt-1 text-xs orange">Only {p.stock} left</p>}{p.stock===0 && <p className="mt-1 text-xs text-red-400">Out of stock</p>}</Link>)}</div>
  </main>
}
