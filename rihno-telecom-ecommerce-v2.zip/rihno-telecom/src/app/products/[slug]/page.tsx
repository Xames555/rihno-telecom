import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { whatsappUrl } from "@/lib/whatsapp"; import { getCurrentUser } from "@/lib/auth";

export default async function ProductPage({ params }: { params: Promise<{slug:string}> }) {
  const {slug}=await params;
  const p=await prisma.product.findUnique({where:{slug},include:{category:true,reviews:{where:{approved:true},include:{user:true},take:10}}});
  if(!p) notFound();
  const price=Number(p.salePrice??p.price); const user=await getCurrentUser();
  const wa=whatsappUrl(`Hello Rihno Telecom, I am interested in ${p.name}. Please provide more information.`);
  return <main className="container py-12"><div className="grid gap-10 md:grid-cols-2">
    <div className="surface flex aspect-square items-center justify-center rounded-3xl text-8xl font-black orange">RT</div>
    <div><p className="text-sm text-white/40">{p.category.name} · SKU {p.sku}</p><h1 className="mt-3 text-4xl font-black">{p.name}</h1><p className="mt-5 text-3xl font-black">৳{price.toLocaleString()}</p>{p.salePrice&&<p className="text-white/40 line-through">৳{Number(p.price).toLocaleString()}</p>}
      <p className="mt-6 leading-7 text-white/60">{p.description}</p><p className="mt-5 text-sm">{p.stock>0?<span className="text-green-400">In stock · {p.stock} available</span>:<span className="text-red-400">Out of stock</span>}</p>
      <div className="mt-8 flex flex-wrap gap-3"><form action="/api/cart" method="post"><input type="hidden" name="productId" value={p.id}/><input type="hidden" name="quantity" value="1"/><button disabled={p.stock===0} className="btn btn-primary disabled:opacity-40">Add to Cart</button></form><a className="btn btn-ghost" href={wa} target="_blank">Chat on WhatsApp</a>{user&&<form action="/api/wishlist" method="post"><input type="hidden" name="productId" value={p.id}/><input type="hidden" name="slug" value={p.slug}/><button className="btn btn-ghost">♡ Wishlist</button></form>}</div>
    </div>
  </div>
  <section className="mt-16 border-t border-white/10 pt-10"><h2 className="text-2xl font-black">Specifications</h2><pre className="mt-4 whitespace-pre-wrap rounded-2xl bg-[#151515] p-5 text-sm text-white/70">{JSON.stringify(p.specs,null,2)}</pre></section>
  <section className="mt-12 border-t border-white/10 pt-10"><h2 className="text-2xl font-black">Reviews</h2>{p.reviews.length?<div className="mt-5 grid gap-3">{p.reviews.map(r=><div key={r.id} className="surface rounded-2xl p-4"><b>{"★".repeat(r.rating)}</b><p className="mt-2 text-white/70">{r.body}</p></div>)}</div>:<p className="mt-4 text-white/50">No approved reviews yet.</p>}{user&&<form action="/api/reviews" method="post" className="surface mt-5 grid gap-3 rounded-2xl p-5"><input type="hidden" name="productId" value={p.id}/><input type="hidden" name="slug" value={p.slug}/><select name="rating" className="input"><option>5</option><option>4</option><option>3</option><option>2</option><option>1</option></select><textarea name="body" required placeholder="Write your review" className="input min-h-28"/><button className="btn btn-primary">Submit review</button></form>}</section></main>
}
