import Link from "next/link";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export default async function Admin(){
  const user=await getCurrentUser();
  if(!user?.role) redirect("/admin/login");
  const [orders,products,customers,sales]=await Promise.all([
    prisma.order.count(), prisma.product.count(), prisma.user.count({where:{role:null}}),
    prisma.order.aggregate({where:{status:{not:"CANCELLED"}},_sum:{total:true}})
  ]);
  return <main className="container py-10"><div className="flex items-center justify-between"><div><p className="orange font-bold">RIHNO TELECOM ADMIN</p><h1 className="text-4xl font-black">Dashboard</h1></div><Link href="/" className="btn btn-ghost">View Store</Link></div>
    <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{[["Sales",`৳${Number(sales._sum.total??0).toLocaleString()}`],["Orders",orders],["Products",products],["Customers",customers]].map(x=><div className="surface rounded-2xl p-5" key={x[0]}><div className="text-sm text-white/50">{x[0]}</div><div className="mt-2 text-3xl font-black">{x[1]}</div></div>)}</div>
    <div className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">{[["Products","/admin/products"],["Categories","/admin/categories"],["Orders","/admin/orders"],["Customers","/admin/customers"],["Banners","/admin/banners"],["CMS Pages","/admin/pages"],["Blog","/admin/blog"],["Coupons","/admin/coupons"],["Reviews","/admin/reviews"],["Settings","/admin/settings"]].map(([label,href])=><Link key={href} className="surface rounded-2xl p-5 font-bold" href={href}>{label} →</Link>)}</div>
  </main>
}
