import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  const adminPhone = process.env.ADMIN_PHONE;
  const adminPassword = process.env.ADMIN_PASSWORD;

  if (adminPhone && adminPassword) {
    const passwordHash = await bcrypt.hash(adminPassword, 12);
    await prisma.user.upsert({
      where: { phone: adminPhone },
      update: { name: "Rihno Telecom Admin", passwordHash, role: "SUPER_ADMIN", active: true },
      create: { name: "Rihno Telecom Admin", phone: adminPhone, passwordHash, role: "SUPER_ADMIN" }
    });
  }

  const categories = [
    ["Smartphones", "smartphones"], ["Mobile Accessories", "mobile-accessories"],
    ["Chargers", "chargers"], ["Cables", "cables"], ["Earphones", "earphones"],
    ["Headphones", "headphones"], ["Power Banks", "power-banks"],
    ["Smart Gadgets", "smart-gadgets"], ["Networking", "networking"], ["Telecom Products", "telecom-products"]
  ];

  for (let i = 0; i < categories.length; i++) {
    await prisma.category.upsert({
      where: { slug: categories[i][1] },
      update: {},
      create: { name: categories[i][0], slug: categories[i][1], sortOrder: i, description: "Demo category — replace with Rihno Telecom content." }
    });
  }

  const cat = await prisma.category.findUnique({ where: { slug: "mobile-accessories" } });
  if (cat) {
    await prisma.product.upsert({
      where: { sku: "DEMO-RT-001" },
      update: {},
      create: {
        name: "Rihno Demo Fast Charger 25W",
        slug: "rihno-demo-fast-charger-25w",
        sku: "DEMO-RT-001",
        shortDesc: "Demo product for the Rihno Telecom storefront.",
        description: "This is a sample product. Replace it from the admin panel before launch.",
        price: 1290,
        salePrice: 990,
        stock: 25,
        categoryId: cat.id,
        featured: true,
        isNew: true,
        images: ["/placeholder-product.svg"],
        specs: { "Power": "25W", "Port": "USB-C", "Warranty": "Demo" },
        seoTitle: "Demo 25W Fast Charger | Rihno Telecom",
        seoDesc: "Sample Rihno Telecom product."
      }
    });
  }

  const defaults = {
    store_name: "Rihno Telecom",
    store_tagline: "Technology That Keeps You Connected.",
    whatsapp: "8801627982049",
    facebook: "",
    instagram: "",
    youtube: "",
    tiktok: "",
    currency: "BDT",
    shipping_charge: "80",
    free_shipping_threshold: "3000",
    default_meta_title: "Rihno Telecom | Technology That Keeps You Connected.",
    default_meta_description: "Shop quality technology products, telecom accessories and smart solutions from Rihno Telecom.",
  };
  for (const [key, value] of Object.entries(defaults)) {
    await prisma.setting.upsert({ where: { key }, update: {}, create: { key, value } });
  }
}

main().finally(() => prisma.$disconnect());
