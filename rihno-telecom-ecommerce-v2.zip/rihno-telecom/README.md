# Rihno Telecom — Production Ecommerce Foundation

A Next.js 16 + TypeScript + PostgreSQL + Prisma 7 ecommerce foundation for Rihno Telecom, designed around a dark/orange technology identity.

## Current capabilities

- Responsive storefront and mobile-friendly layout
- Product/category database models
- Searchable product listing
- Product detail pages
- Cookie-backed cart
- Checkout and order creation
- Stock decrement + inventory log in a database transaction
- Cash on Delivery architecture
- Admin login with hashed passwords and signed HTTP-only session cookie
- Admin dashboard, product/order/settings views
- WhatsApp product/contact CTAs
- Dynamic sitemap and robots.txt
- SEO metadata foundation
- PostgreSQL/Prisma schema covering products, variants, orders, users, coupons, reviews, wishlist, banners, CMS pages, blog posts and settings
- Bangladesh currency/phone defaults

## Important production note

This repository is a real application foundation, not a hosted service. Before public launch, complete and verify the external integrations and operational controls that require your credentials/provider accounts: payment gateway (bKash/Nagad/SSLCommerz), transactional email/SMS, object storage, analytics, CAPTCHA/anti-abuse, backups/monitoring, and your final legal/policy content.

The database schema already contains the core entities needed to extend these areas cleanly.

## Requirements

Use Node.js 24 LTS where possible. Next.js 16 is Active LTS. Prisma 7 is used here as the stable Prisma line; Prisma 8 is a release candidate at the time this project was generated.

## Setup

1. Copy `.env.example` to `.env`.
2. Set `DATABASE_URL` to your PostgreSQL database.
3. Set a long random `AUTH_SECRET`.
4. Set `NEXT_PUBLIC_SITE_URL`.
5. Install dependencies:

```bash
npm install
```

6. Create database tables:

```bash
npm run db:migrate
```

7. Create the initial admin securely using environment variables:

```bash
ADMIN_PHONE="+8801XXXXXXXXX" ADMIN_PASSWORD="use-a-strong-unique-password" npm run db:seed
```

Do not commit these values to source control.

8. Start development:

```bash
npm run dev
```

9. Production:

```bash
npm run build
npm start
```

## Domain / DNS

Point your domain's DNS to the hosting provider you choose. For Vercel, add the domain in the project settings and follow the provider's displayed DNS records. The provider can provision HTTPS automatically. Do not claim a domain is registered until you actually register it.

## SEO

Set `NEXT_PUBLIC_SITE_URL` to the canonical HTTPS domain. The app generates `/sitemap.xml` and `/robots.txt`. Add Google Search Console verification/analytics through the settings architecture before launch.

## Payment gateway

Do not put gateway secrets in browser code. Add server-side provider adapters under `src/lib/payments/`, store credentials only in environment variables, create the payment transaction server-side, and verify webhooks before changing `paymentStatus` to PAID.

## Recommended next production hardening

- Add CSRF/origin checks to state-changing form endpoints.
- Add rate limiting for login, checkout, reviews and order tracking.
- Add object-storage uploads with MIME/type/size validation and signed upload URLs.
- Add full admin CRUD for products/categories/orders/banners/CMS/blog/settings.
- Add customer registration/login/password reset and account pages.
- Add review approval, wishlist and coupon enforcement endpoints.
- Add invoice PDF generation.
- Add payment gateway adapters and verified webhooks.
- Add email/SMS/WhatsApp notification workers.
- Add automated tests and CI.
- Add error monitoring, database backups, audit logs and operational alerts.
- Replace all demo content and legal pages before launch.

## Project structure

- `src/app` — Next.js pages and API routes
- `src/lib` — database/auth/WhatsApp helpers
- `prisma/schema.prisma` — production data model
- `prisma/seed.ts` — demo categories/product + secure first-admin creation

## Build pass 2 additions

- Customer registration/login/logout/account and password-reset token storage
- Wishlist toggle and wishlist page
- Customer reviews with admin moderation
- Coupon validation and atomic usage counting at checkout
- Admin CRUD-oriented screens for products, categories, orders, banners, CMS pages, blog, coupons, reviews, customers and settings
- Admin edit routes for products/categories and order status/payment status updates
- Invoice HTML generation route suitable for browser print-to-PDF
- Payment provider abstraction boundary for bKash/Nagad/SSLCommerz without fake credentials
- Notification provider abstraction boundary for email/SMS/WhatsApp
- Rate limiting on authentication flows
- Blog storefront pages
- Order tracking result page

### Production integration boundaries

Payment provider credentials, object storage credentials, email/SMS/WhatsApp credentials, analytics IDs and domain verification values must be supplied through environment variables or secure settings. The project intentionally does not pretend those services are connected.

For real PDF files rather than browser print-to-PDF, add a server-side PDF renderer such as PDFKit or a managed PDF service and keep it server-only.
